const reviewData = [
    {
      name: "Alice",
      date: "2022-01-01",
      rating: 4,
      review: "I really enjoyed playing this game!"
    },
    {
      name: "Bob",
      date: "2022-02-14",
      rating: 5,
      review: "This is the best game ever!"
    },
    {
      name: "Charlie",
      date: "2022-03-20",
      rating: 3,
      review: "It was okay, but nothing special."
    },
    {
      name: "David",
      date: "2022-04-30",
      rating: 2,
      review: "I didn't really like it. It was too hard."
    },
    {
      name: "Eve",
      date: "2022-05-15",
      rating: 4,
      review: "Fun game, but could use some more levels."
    }
  ];
  
  export default reviewData;